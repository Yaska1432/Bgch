void synchronize (int total_threads);
